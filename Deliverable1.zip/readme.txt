SEG2105 Deliverable 1
Ivana Erlich, Anshu Sharma, Batuhan Basoglu, Mary Tran 
https://github.com/ebivibe/SEG2105-Olympus