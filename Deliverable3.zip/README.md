# SEG2105-Olympus
SEG2105 final project, Ivana Erlich, Anshu Sharma, Batuhan Basoglu, Mary Tran

https://github.com/ebivibe/SEG2105-Olympus

Admin account is precreated with 
username = admin, 
password = admin


ServiceProvider account is precreated with 
username = testing, 
password = testing

APK tested on a Sony Xperia XA2, model H3123
